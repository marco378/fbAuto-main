This folder should contain the extension icons:
- icon-16.png
- icon-48.png
- icon-128.png

Replace these with your own icons before loading the extension.
